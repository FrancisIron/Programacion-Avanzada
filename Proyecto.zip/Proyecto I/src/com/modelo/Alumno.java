package com.modelo;

import java.util.ArrayList;

public class Alumno {
    
    private String nombre;
    private String curso;
    private Apoderado apoderado;
    private ArrayList<Boolean> asistenciaClases;
    private double[][] calificaciones;
    private ArrayList<Anotaciones> anotaciones;
    
    public Alumno(String nombre, String curso) {
        this.nombre = nombre;
        this.curso = curso;        
        this.anotaciones = new ArrayList();
        this.asistenciaClases = new ArrayList();
        this.calificaciones = new double[5][5];
    }
    
    public ArrayList<Boolean> getAsistenciaClases() {
        return asistenciaClases;
    }
    
    public void setAsistenciaClases(ArrayList<Boolean> asistenciaClases) {
        this.asistenciaClases = asistenciaClases;
    }
    
    public double[][] getCalificaciones() {
        return calificaciones;
    }
    
    public void setCalificaciones(double[][] calificaciones) {
        this.calificaciones = calificaciones;
    }
    
    public ArrayList<Anotaciones> getAnotaciones() {
        return anotaciones;
    }
    
    public void setAnotaciones(ArrayList<Anotaciones> anotaciones) {
        this.anotaciones = anotaciones;
    }
    
    public Apoderado getApoderado() {
        return apoderado;
    }
    
    public void setApoderado(Apoderado apoderado) {
        this.apoderado = apoderado;
    }
    
    public void ingresarAnotacion(String contenido, String tipo) {
        anotaciones.add(new Anotaciones(contenido, tipo));
    }
    
    public void verAnotaciones() {
        // TODO - implement Alumno.verAnotaciones
        throw new UnsupportedOperationException();
    }

    /**
     * [PosicionAsignatura][PosicionNota] 
     * [1][] - Lenguaje 
     * [2][] - Matematicas
     * [3][] - Ciencias Naturales 
     * [4][] - Ciencias Sociales 
     * [5][] - Educación Fisica
     */
    public void ingresarNota(int posAsign, int posNota, double nota) {
        calificaciones[posAsign][posNota] = nota;
    }
    
    public double getNota(int posAsign, int posNota) {
        double nota = calificaciones[posAsign][posNota];
        return nota;
    }
    
    public void modificarNota(int posAsign, int posNota, double nota) {
       calificaciones[posAsign][posNota] = nota; 
    }    
    
    public void ingresarAsistencia(Boolean state) {
        asistenciaClases.add(state);
    }
    
    public void obtenerPCT_Asistencia() {
        // TODO - implement Alumno.obtenerPCT_Asistencia
        throw new UnsupportedOperationException();
    }
    
    public void verAsistencia() {
        // TODO - implement Alumno.verAsistencia
        throw new UnsupportedOperationException();
    }
    
    public String getNombre() {
        return nombre;
    }
    
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    public String getCurso() {
        return curso;
    }
    
    public void setCurso(String curso) {
        this.curso = curso;
    }
    
}
