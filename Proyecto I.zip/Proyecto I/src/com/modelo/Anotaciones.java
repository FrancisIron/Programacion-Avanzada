package com.modelo;
    /**
     * Clase que representa una anotacion para los antecedente del alumno
     * @author Francisco Fierro
     */
public class Anotaciones {
    
    private String contenido;
    private String tipo;
    /**
     * Constructor de la clase Anotaciones
     * @param contenido Motivo o causa por la cual se le puso la anotacion
     * @param tipo Tipo de la anotacion que puede ser positiva o negativa
     */
    public Anotaciones(String contenido, String tipo) {
        this.contenido=contenido;
        this.tipo=tipo;
    }   
    
    public String getContenido() {
        return this.contenido;
    }
    
    public void setContenido(String contenido){
        this.contenido = contenido;
    }
    
    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
    
    
}
