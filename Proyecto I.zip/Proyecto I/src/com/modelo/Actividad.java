package com.modelo;
    /**
     * Clase que representa una actividad dentro de la planificacion
     * @author Francisco Fierro
     */
public class Actividad {

	private String nombre;
	private String contenido;
	private String fecha;
        /**
         * Constructor de la clase Actividad
         * @param nombre Nombre o tipo de la actividad
         * @param contenido Objetivo a conseguir o de que se trata la actividad
         * @param fecha Fecha en la cual se va a realizar la actividad
         */
    public Actividad(String nombre, String contenido, String fecha) {
        this.nombre = nombre;
        this.contenido = contenido;
        this.fecha = fecha;
    }	
        
        /**
         * Getter del Nombre
         * @return nombre 
         */
	public String getNombre() {
		return this.nombre;
	}

	/**
	 * Setter del Nombre
	 * @param nombre Nombre o tipo de la actividad
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
        
        /**
         * Getter del Contenido  
         * @return contenido
         */
	public String getContenido() {
		return this.contenido;
	}

	/**
	 * Setter del Contenido
	 * @param contenido Objetivo a conseguir o de que se trata la actividad
	 */
	public void setContenido(String contenido) {
		this.contenido = contenido;
	}
        
        /**
         * Getter de la Fecha
         * @return fecha
         */
	public String getFecha() {
		return this.fecha;
	}

	/**
	 * Setter de Fecha 
	 * @param fecha Fecha en la cual se va a realizar la actividad
	 */
	public void setFecha(String fecha) {
		this.fecha = fecha;
	}

}