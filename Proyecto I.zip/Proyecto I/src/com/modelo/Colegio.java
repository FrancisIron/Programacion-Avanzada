package com.modelo;

import java.util.ArrayList;

    /**
     * Clase que representa y/o simula un colegio
     * @author Francisco Fierro
     */
public class Colegio {

    private String nombre;
    private ArrayList<Curso> cursos;    
    /**
     * Constructor de la clase Colegio
     */
    public Colegio() {        
        this.cursos = new ArrayList();        
    }    

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public ArrayList<Curso> getCursos() {
        return cursos;
    }

    public void setCursos(ArrayList<Curso> cursos) {
        this.cursos = cursos;
    }    
    /**
     * Metodo en el cual anade un curso al ArrayList() cursos
     * @param gradoCurso Nivel y letra del curso a crear
     */    
    public void anadirCurso(String gradoCurso) {
        cursos.add(new Curso(gradoCurso));
    }

    public void generarInforme() {
        // TODO - implement Colegio.generarInforme
        throw new UnsupportedOperationException();
    }    

    public void generarInforme_Planificacion() {
        // TODO - implement Colegio.generarInforme_Planificacion
        throw new UnsupportedOperationException();
    }

}
