package com.modelo;

import java.util.ArrayList;
    /**
     * Clase que representa a un apoderado que se hace cargo de un alumno
     * @author Francisco Fierro
     */
public class Apoderado {

    private String nombre;
    private ArrayList<Alumno> pupilos;
    /**
     * Constructor de la clase Apoderado
     * @param nombre Nombre del apoderado
     */
    public Apoderado(String nombre) {
        this.nombre = nombre;
        this.pupilos = new ArrayList();
    }

    public ArrayList<Alumno> getPupilos() {
        return pupilos;
    }

    public void setPupilos(ArrayList<Alumno> pupilos) {
        this.pupilos = pupilos;
    }

    public String getNombre() {
        return this.nombre;
    }

    
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void solicitarInforme() {
        // TODO - implement Apoderado.solicitarInforme
        throw new UnsupportedOperationException();
    }
    /**
     * Metodo que anade un alumno al ArrayList() pupilos del apoderado
     * @param pupilo Alumno que se va a anadir a al ArrayList() pupilos
     */
    public void anadirPupilo(Alumno pupilo){
        pupilos.add(pupilo);
    }
}
