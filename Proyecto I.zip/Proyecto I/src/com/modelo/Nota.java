package com.modelo;
    /**
     * Clase que representa una nota que se encuentra dentro del libro de clases
     * @author Francisco Fierro
     */
public class Nota {
    private double nota;
    private String asignatura;
    private String contenido;
    /**
     * Constructor de la clase Nota
     * @param nota Valor numerico de la nota
     * @param asignatura Asignatura a la cual pertenece la nota
     * @param contenido Motivo o causa por la cual se le puso la nota
     */
    public Nota(double nota, String asignatura, String contenido) {
        this.nota = nota;
        this.asignatura = asignatura;
        this.contenido = contenido;
    }

    public double getNota() {
        return nota;
    }

    public void setNota(double nota) {
        this.nota = nota;
    }

    public String getAsignatura() {
        return asignatura;
    }

    public void setAsignatura(String asignatura) {
        this.asignatura = asignatura;
    }

    public String getContenido() {
        return contenido;
    }

    public void setContenido(String contenido) {
        this.contenido = contenido;
    }
    
}