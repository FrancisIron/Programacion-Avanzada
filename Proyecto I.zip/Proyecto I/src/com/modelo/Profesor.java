package com.modelo;
    /**
     * Clase que representa un Profesor, que esta a cargo de una asignatura
     * @author Francisco Fierro
     */
public class Profesor {

    private String nombre;
    private String especialidad;
    /**
     * Constructor de la clase Profesor
     * @param nombre Nombre del profesor
     * @param especialidad Asignatura del profesor
     */
    public Profesor(String nombre, String especialidad) {
        this.nombre = nombre;
        this.especialidad = especialidad;
    }

    public String getNombre() {
        return this.nombre;
    }

    
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void generarReporte_Notas() {
        // TODO - implement Profesor.generarReporte_Notas
        throw new UnsupportedOperationException();
    }

    public String getEspecialidad() {
        return especialidad;
    }

    public void setEspecialidad(String especialidad) {
        this.especialidad = especialidad;
    }
}
