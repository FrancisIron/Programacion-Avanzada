package com.modelo;

import java.util.ArrayList;
    /**
     * Clase que representa a un curso perteneciente de un colegio
     * @author Francisco Fierro
     */
public class Curso {

    private ArrayList<Alumno> listaAlumnos;
    private ArrayList<Asignatura> listaAsignaturas;
    private String curso;

    public Curso(String curso) {
        this.curso = curso;
        this.listaAlumnos = new ArrayList();
        this.listaAsignaturas = new ArrayList();
    }

    public ArrayList<Alumno> getListaAlumnos() {
        return listaAlumnos;
    }

    public void setListaAlumnos(ArrayList<Alumno> listaAlumnos) {
        this.listaAlumnos = listaAlumnos;
    }

    public ArrayList<Asignatura> getListaAsignaturas() {
        return listaAsignaturas;
    }

    public void setListaAsignaturas(ArrayList<Asignatura> listaAsignaturas) {
        this.listaAsignaturas = listaAsignaturas;
    }

    public String getCurso() {
        return this.curso;
    }
    
    public void setCurso(String curso) {
        this.curso = curso;
    }

    /**
     * Metodo en el cual se crean y anade alumnos al ArrayList() listaAlumnos
     * @param nom Nombre del alumno
     * @param cur Nivel y letra del curso
     */
    public void anadirAlumno(String nom, String cur) {
        listaAlumnos.add(new Alumno(nom, cur));
    }

    /**
     * Metodo en el cual se modifica al alumno guardado en el ArrayList() listaAlumnos
     * @param i Indice en el cual se encuentra el alumno a modificar en el ArrayList() listaAlumnos
     * @param novoNom Nombre del alumno
     * @param novoCur Nivel y letra del curso
     */
    public void modificarAlumno(int i, String novoNom, String novoCur) {
        listaAlumnos.get(i).setNombre(novoNom);
        listaAlumnos.get(i).setCurso(novoCur);
    }    
    
    public Alumno getAlumno (int i){
        return listaAlumnos.get(i);
    }
    
    public Asignatura getAsignatura (int i){
        return listaAsignaturas.get(i);
    }

    public void eliminarAlumno(int i) {
        listaAlumnos.remove(i);
    }
    /**
     * Metodo que anade una Asignatura al ArrayList() listaAsignaturas
     * @param nomAsign Nombre de la asignatura
     * @param nomProf Nombre del profe a cargo de la asignatura
     * @param contenidoPlan Objetivo de la asignatura
     */
    public void anadirAsignatura(String nomAsign, String nomProf, String contenidoPlan) {
        listaAsignaturas.add(new Asignatura(nomAsign, new Profesor(nomProf, nomAsign), new Planificacion(contenidoPlan)));
    }
    /**
     * Metodo en el cual se modifica una Asignatura en el ArrayList() listaAsignaturas
     * @param i Indice en el cual se encuentra la asignatura a modificar en el ArrayList() listaAsignaturas
     * @param nombreAsignatura Nombre de la asignatura
     * @param nomProf Nombre del profe a cargo de la asignatura
     */
    public void modificarAsignatura(int i, String nombreAsignatura, String nomProf) {
        listaAsignaturas.get(i).setNombre(nombreAsignatura);
        listaAsignaturas.get(i).modificarProfesor_Cargo(nomProf);        
    }  
    /**
     * Metodo con el cual se elimina una Asignatura en el ArrayList() listaAsignaturas
     * @param i Indice en el cual se encuentra la asignatura a eliminar en el ArrayList() listaAsignaturas 
     */
    public void eliminarAsignatura(int i) {
        listaAsignaturas.remove(i);
    }

}
