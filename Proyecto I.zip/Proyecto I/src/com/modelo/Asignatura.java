package com.modelo;
    /**
     * Clase que representa una asignatura junto con su planificacion
     * @author Francisco Fierro
     */
public class Asignatura {

    private String nombre;
    private Planificacion planificacion;
    private Profesor profesorCargo;

    /**
     * Constructor de la clase Asignatura
     *
     * @param nombre Nombre de la Asignatura
     * @param profesorCargo Profesor a cargo de la asignatura
     * @param planificacion Planificacion de la asignatura
     */
    public Asignatura(String nombre, Profesor profesorCargo, Planificacion planificacion) {
        this.nombre = nombre;
        this.profesorCargo = profesorCargo;
        this.planificacion = planificacion;
    }

    public Planificacion getPlanificacion() {
        return planificacion;
    }

    public void setPlanificacion(Planificacion planificacion) {
        this.planificacion = planificacion;
    }

    public Profesor getProfesorCargo() {
        return profesorCargo;
    }

    public void setProfesorCargo(Profesor profesorCargo) {
        this.profesorCargo = profesorCargo;
    }

    public void ingresarActividad(String nombre, String contenido, String fecha) {
        planificacion.anadirActividad(nombre, contenido, fecha);
    }

    /**
     * Metodo en el cual se le modifica la planificacion de la asignatura
     * @param novoContenido_Planificacion Objetivo de la asignatura 
     */
    public void modificarPlanificacion(String novoContenido_Planificacion) {
        planificacion.setContenido(novoContenido_Planificacion);
    }

    public String getNombre() {
        return this.nombre;
    }

    
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Metodo en el cual se le modifica el Profesor a cargo de la Asignatura
     * @param nom Nombre del profesor
     */
    public void modificarProfesor_Cargo(String nom) {
        profesorCargo.setNombre(nom);
        profesorCargo.setEspecialidad(nombre);
    }

}
