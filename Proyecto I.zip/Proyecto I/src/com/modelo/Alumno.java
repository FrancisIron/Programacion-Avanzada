package com.modelo;

import java.util.ArrayList;

/**
 * Clase que repesenta a un alumno y que es parte de un curso
 *
 * @author Francisco Fierro
 */
public class Alumno {

    private String nombre;
    private String curso;
    private Apoderado apoderado;
    private ArrayList<Boolean> asistenciaClases;
    private ArrayList<Nota> calificaciones;
    private ArrayList<Anotaciones> anotaciones;

    /**
     * Contructor de la clase Alumno
     *
     * @param nombre Nombre del alumno
     * @param curso Curso del alumno
     */
    public Alumno(String nombre, String curso) {
        this.nombre = nombre;
        this.curso = curso;
        this.anotaciones = new ArrayList();
        this.asistenciaClases = new ArrayList();
        this.calificaciones = new ArrayList();
    }

    public ArrayList<Boolean> getAsistenciaClases() {
        return asistenciaClases;
    }

    public void setAsistenciaClases(ArrayList<Boolean> asistenciaClases) {
        this.asistenciaClases = asistenciaClases;
    }

    public ArrayList<Nota> getCalificaciones() {
        return calificaciones;
    }

    public void setCalificaciones(ArrayList<Nota> calificaciones) {
        this.calificaciones = calificaciones;
    }

    public ArrayList<Anotaciones> getAnotaciones() {
        return anotaciones;
    }

    public void setAnotaciones(ArrayList<Anotaciones> anotaciones) {
        this.anotaciones = anotaciones;
    }

    public Apoderado getApoderado() {
        return apoderado;
    }

    public void setApoderado(Apoderado apoderado) {
        this.apoderado = apoderado;
    }

    /**
     * Metodo en el cual se le ingresa la anotacion al alumno
     *
     * @param contenido Motivo o causa por la cual se le puso la anotacion
     * @param tipo Tipo de la anotacion que puede ser positiva o negativa
     */
    public void ingresarAnotacion(String contenido, String tipo) {
        anotaciones.add(new Anotaciones(contenido, tipo));
    }

    /**
     * Metodo que modifica una anotacion al alumno
     *
     * @param i Indice en el cual se encuentra la anotacion a modificar en el
     * ArrayList() asistenciaClases
     * @param contenido Motivo o causa por la cual se le puso la anotacion
     * @param tipo Tipo de la anotacion que puede ser positiva o negativa
     */
    public void modificarAnotaciones(int i, String contenido, String tipo) {
        anotaciones.get(i).setContenido(contenido);
        anotaciones.get(i).setTipo(tipo);
    }

    /**
     * Metodo en el cual se le ingresa la nota al alumno
     *
     * @param nota Valor numerico de la nota a registrar
     * @param asignatura Asignatura de la nota a registrar
     * @param contenido Motivo o causa por la cual se obtuvo la nota
     */
    public void ingresarNota(double nota, String asignatura, String contenido) {
        calificaciones.add(new Nota(nota, asignatura, contenido));
    }

    /**
     * Metodo en el cual se le modifica la nota al alumno
     *
     * @param i Indice en el cual se encuentra la nota a modificar en el
     * ArrayList() calificaciones
     * @param nota Valor numero de la nota a modificar
     * @param contenido Motivo o causa por la cual se obtuco la nota
     */
    public void modificarNota(int i, double nota, String contenido) {
        calificaciones.get(i).setNota(nota);
        calificaciones.get(i).setContenido(contenido);
    }

    /**
     * Metodo en el cual se le ingrgesa la asistencia al alumno
     *
     * @param state Estado que registra si el alumno asistio o no a clases
     */
    public void ingresarAsistencia(Boolean state) {
        asistenciaClases.add(state);
    }

    /**
     * Metodo en el cual se obtiene el porcentaje de asistencia y con el cual se
     * analiza la situación del alumno
     */
    public void obtenerPCT_Asistencia() {
        // TODO - implement Alumno.obtenerPCT_Asistencia
        throw new UnsupportedOperationException();
    }

    public String obtenerPRM_Asignatura(int Asignatura) {
        double suma = 0;
        for (int i = 5 * Asignatura; i < 5 * Asignatura + 5; i++) {
            suma+= calificaciones.get(i).getNota();
        }
        String str  = ""+suma/5;
        str= str.substring(0, 3);
        return str;
    }

    public String obtenerPRM_general(){
        double suma=0;
        for(int i=0; i<5; i++){
            suma+=Double.parseDouble(obtenerPRM_Asignatura(i));
        }
        String str  = ""+suma/5;
        str= str.substring(0, 3);
        return str;
    }
    
    /**
     * Metodo en el cual se le modifica la asistencia al alumno
     *
     * @param i Indice en el cual se encuentra la asistencia a modificar en el
     * ArrayList() asistenciaClases
     * @param state Estado que registra si el alumno asistio o no a clases
     */
    public void modificarAsistencia(int i, Boolean state) {
        asistenciaClases.set(i, state);
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCurso() {
        return curso;
    }

    public void setCurso(String curso) {
        this.curso = curso;
    }

}
