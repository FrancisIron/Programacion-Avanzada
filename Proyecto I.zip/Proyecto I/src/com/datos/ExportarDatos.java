package com.datos;

import java.io.File;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
    /**
     * Clase a cargo de generar archivos a partir del XML o el JSON del programa
     * @author Francisco Fierro
     */
public class ExportarDatos {

    public void exportarExcel() throws TransformerException{        
        File stylesheet = new File("C:/Users/R22bot2.15 Pocket/Documents/Respaldo/Respaldo/Proyecto I/test/asignaturaexcel.xsl");
        File xmlfile = new File("C:/Users/R22bot2.15 Pocket/Documents/Respaldo/Respaldo/Proyecto I/test/archivo.xml");
        StreamSource stylesource = new StreamSource(stylesheet);
        StreamSource xmlsource = new StreamSource(xmlfile);
        Transformer transformer = TransformerFactory.newInstance().newTransformer(stylesource);
        transformer.transform(xmlsource, new StreamResult(new File("C:/Users/R22bot2.15 Pocket/Documents/Respaldo/Respaldo/Proyecto I/test/excel.xls")));
        StreamResult consoleOut = new StreamResult(System.out);
        transformer.transform(xmlsource, consoleOut);
    }
}
