package com.datos;

import com.modelo.Curso;
import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.StaxDriver;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import org.json.XML;

/**
 * Clase que guarda los datos del programa
 *
 * @author Francisco Fierro
 */
public class GuardarDatos {

    /**
     * Toma un objeto, lo transforma a XML y desde ese XML lo transforma a JSON
     *
     * @param target Objeto a transformarse
     */
    public void parserXMLtoJSON(Object target) throws IOException, TransformerException {
        XStream parsel = new XStream(new StaxDriver());
        String xml = parsel.toXML(target);
        Path archivo = Paths.get("test/archivo.json");
        Files.write(archivo, XML.toJSONObject(xml).toString().getBytes());
        System.out.println("JSON creado");
    }

    /**
     * Toma un objeto y lo transforma a XML 
     *
     * @param target Objeto a transformarse
     */
    public void parserXML(Object target) throws IOException {
        XStream parsel = new XStream(new StaxDriver());
        String xml = parsel.toXML(target);
        Path archivo = Paths.get("test/archivo.xml");
        Files.write(archivo, xml.getBytes());
        System.out.println("XML creado");
    }
    
    public void parserXML(Object target,String nivel) throws IOException {
        XStream parsel = new XStream(new StaxDriver());
        String xml = parsel.toXML(target);
        Path archivo = Paths.get("test/curso"+nivel+".xml");
        Files.write(archivo, xml.getBytes());
        System.out.println("XML creado");
    }
    
    public void XMLtoExcel (String nivel) throws TransformerException{
        File stylesheet = new File("test/asignaturaexcel.xsl");
        File xmlfile = new File("test/curso"+nivel+".xml");
        StreamSource stylesource = new StreamSource(stylesheet);
        StreamSource xmlsource = new StreamSource(xmlfile);
        Transformer transformer = TransformerFactory.newInstance().newTransformer(stylesource);
        transformer.transform(xmlsource, new StreamResult(new File("test/excel"+nivel+".xls")));
        StreamResult consoleOut = new StreamResult(System.out);
        transformer.transform(xmlsource, consoleOut);
    }
}
